import hashlib
import shutil



#Documentation: https://www.geeksforgeeks.org/python-copy-contents-of-one-file-to-another-file/

# ********************************************************************************************
# Task 1 Functions

def tinyHashFunct(Hash):
  tinyHash = Hash[0:5]
  return tinyHash

def MD5hash(filename):
  byteHash = hashlib.md5(filename.read()).digest()
  Hash = byteHash.hex()
  return Hash

def copyFile(fileName,file):
  shutil.copyfile(file.name, fileName)
  newFile = open(fileName, "rb+")
  return newFile

def addWord(newFile, dict):
  newFile.write(dict)
  return newFile
  
def checkCollision(tinyHash, newFile):
  Hash = MD5hash(newFile)
  newTinyHash = tinyHashFunct(Hash)
  if(newTinyHash == tinyHash):
    return 1
  else:
    return 0
  
def task1():
  print("Running hash collision for file:   samplefile.txt")

  # Read file
  file = open("samplefile.txt","rb+")

  # Get Hash and Tiny Hash
  Hash = MD5hash(file)
  print("Full MD5 digest is:\t", Hash)
  tinyHash = tinyHashFunct(Hash)
  print("TinyHash is:\t",tinyHash)

  dict = open("words.txt", "rb").readlines()
  timesIndexed = 0
  j = 0
  

  for i in range(1):
    fileName = "collision" + str(i+1) + ".txt"
    check = 0
    
    words = 0
    
    while(check == 0):
      newFile = copyFile(fileName, file)
      if(timesIndexed > 0):
        for i in range(timesIndexed + 1):
          addWord(newFile, dict[timesIndexed])
        
      if(j >= len(dict)):
        timesIndexed += 1
        j = 0
        
      else:
        
        addWord(newFile, dict[j])
        words += 1
        same = checkCollision(tinyHash, newFile)

      if(same == 1):
        print("Found TinyHash collision #\t", i+1,"\tafter trying\t", words,"\twords.")
        print("Collision saved as file:\t", fileName)
        check = 1
      else:
        j += 1
        newFile.close()
        
    newFile.close()
    i += 1

  newFile.close()
  file.close()
  

# *********************************************************************************************
  # Task 2

def findCollision(tinyHash, fileName):
  found = False

  # Set initial number to be less than original
  i = int(100000 - 1)

  # Count from 100000 down until hash is found
  while found != True:
    
    # Write this line to file
    new_last_line = ("This is a contract between Alice and Bob. Alice agrees to sell to Bob her NFT art for a price of: $",str(i))

    
    newFile = open(fileName, "w")
    # now write the modified list back out to the file
    newFile.writelines(new_last_line)
    newFile.close()

    newFile = open(fileName,"rb")

    newHash = MD5hash(newFile)
    newTinyHash = newHash[0:5]
    newFile.close()
    
    if(newTinyHash == tinyHash):
      print("Found TinyHash collision using this number:\t", int(i))
      print("New contract saved to file:\t", newFile.name)
      found = True
    i -= 1


def task2():
  print("\nRunning hash collision for file:   contract.txt")
  
  # Read file
  file = open("contract.txt","rb")

  # Get Hash and Tiny Hash
  Hash = MD5hash(file)
  print("Full MD5 digest is:\t", Hash)
  tinyHash = tinyHashFunct(Hash)
  print("TinyHash is:\t",tinyHash)

  fileName = "newcontract.txt"
  newFile = copyFile(fileName, file)
  newFile.close()

  findCollision(tinyHash, fileName)


  newFile.close()
  file.close()


def main():
  # Intro statement
  print("CyS 431 PEX2 - Hash Collider - by Cadet Spencer Anderson\n")

  # Task 1
  print("Starting Task 1...\n")
  task1()

  # Task 2
  print("Starting Task 2...\n")
  #task2()


#***************************************************************************

# Main Function
  
main()